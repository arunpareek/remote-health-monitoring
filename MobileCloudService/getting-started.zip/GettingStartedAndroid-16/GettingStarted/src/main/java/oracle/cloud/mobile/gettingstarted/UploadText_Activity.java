package oracle.cloud.mobile.gettingstarted;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import oracle.cloud.mobile.exception.ServiceProxyException;
import oracle.cloud.mobile.mobilebackend.MobileBackendManager;
import oracle.cloud.mobile.storage.Storage;
import oracle.cloud.mobile.storage.StorageCollection;
import oracle.cloud.mobile.storage.StorageObject;


public class UploadText_Activity extends Activity {

    private String collectionID = "YOUR_COLLECTION_NAME";
    private String mPayload; //can be other data
    private String mContentType; //can be other MIME types
    private RadioGroup radioGroup;
    private Button uploadButton;
    private RadioButton choice;
    EditText editText;
    EditText name;
    private Storage mStorage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_text);
        addListenerOnRadioGroup();

    }

    private void addListenerOnRadioGroup() {
        radioGroup = (RadioGroup)findViewById(R.id.radioGroup);
        editText = (EditText)findViewById(R.id.editText);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                checkedId = radioGroup.getCheckedRadioButtonId();
                choice = (RadioButton)findViewById(checkedId);

                if(choice.getText().toString().equals("plain/text")){
                    editText.setText("");
                }
                else {
                    editText.setText("{'key':'value', 'key': 'value'}");
                }
            }
        });

        uploadButton = (Button)findViewById(R.id.upload_button);
        uploadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mPayload = editText.getText().toString();

                if(mPayload.trim().equals("")){
                    Toast.makeText(getApplicationContext(), "Please enter value for payload", Toast.LENGTH_SHORT).show();
                    editText.requestFocus();
                    return;
                }
                else {
                    mPayload = editText.getText().toString();
                    mContentType = choice.getText().toString();
                    uploadObject(mPayload, mContentType);
                }
            }
        });
    }


    private void uploadObject(String payload, String contentType) {

        name = (EditText)findViewById(R.id.editText2);
        try {
            //Initialize and obtain the storage client
            mStorage = MobileBackendManager.getManager().getDefaultMobileBackend(this).getServiceProxy(Storage.class);
            //Fetch the collection
            StorageCollection collection = mStorage.getStorageCollection(collectionID);
            //Create an object, payload and content-Type explicitly specified
            //Id is not needed when uploading an object with POST operation
            StorageObject object = new StorageObject(null, payload.getBytes(), contentType);
            object.setDisplayName(name.getText().toString());
            //Upload the object
            collection.post(object);
//            String objectID = object.getID();
//            SavePreferences(collectionID, objectID);
            launchMainActivity();

        } catch (ServiceProxyException e) {
            e.printStackTrace();
        }
    }


    private void launchMainActivity() {
        Intent intent = new Intent(getCurrentActivity(), MainActivity.class);
        startActivity(intent);
    }

    private Activity getCurrentActivity() {
        return this;
    }

//    private void SavePreferences(String collection, String objectID) {
//        SharedPreferences appPreferences = this.getSharedPreferences("Storage API",
//                Context.MODE_PRIVATE);
//        SharedPreferences.Editor prefEditor = appPreferences.edit();
//        prefEditor.putString("CollectionID", collection);
//        prefEditor.putString("TextObjectID", objectID);
//        prefEditor.apply();
//    }
}