package oracle.cloud.mobile.gettingstarted;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import oracle.cloud.mobile.authorization.AuthorizationAgent;
import oracle.cloud.mobile.authorization.AuthorizationCallback;
import oracle.cloud.mobile.exception.ServiceProxyException;
import oracle.cloud.mobile.logger.Logger;
import oracle.cloud.mobile.mobilebackend.MobileBackendManager;


public class LoginActivity extends Activity {

    private EditText inputUserName;
    private EditText inputPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        inputUserName = (EditText) findViewById(R.id.userName);
        inputPassword = (EditText) findViewById(R.id.passWord);
        Button loginButton = (Button) findViewById(R.id.loginButton);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signIn();
            }
        });
    }

    //This method set up the oAuth Client and make attempt to get oAuth token from the MCS OAuth service
    private void signIn(){
        String userName = inputUserName.getText().toString();
        String passWord = inputPassword.getText().toString();

        try {
            AuthorizationAgent authorizationAgent = MobileBackendManager.getManager().getDefaultMobileBackend(this).getAuthorization();
            AuthorizationCallback callback = new AuthorizationCallback() {
                @Override
                public void onCompletion(ServiceProxyException e) {
                    if(e != null)
                        Logger.debug("DemoApp", "Exception in authentication");
                    else {
                        Logger.debug("DemoApp", "Succeed in authentication");

                        launchMainActivity();
                    }
                }
            };
            authorizationAgent.authenticate(this, userName, passWord, callback);
        } catch (ServiceProxyException e) {
            e.printStackTrace();
        }
    }

    private void launchMainActivity(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}
