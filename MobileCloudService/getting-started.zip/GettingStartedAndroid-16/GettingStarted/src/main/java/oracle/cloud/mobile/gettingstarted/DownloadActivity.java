package oracle.cloud.mobile.gettingstarted;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;

import oracle.cloud.mobile.exception.ServiceProxyException;
import oracle.cloud.mobile.logger.Logger;
import oracle.cloud.mobile.mobilebackend.MobileBackendManager;
import oracle.cloud.mobile.storage.Storage;
import oracle.cloud.mobile.storage.StorageCollection;
import oracle.cloud.mobile.storage.StorageObject;


public class DownloadActivity extends Activity {
    private Storage mStorage;
    private Context mContext = this;
    private String mCollectionID = "YOUR_COLLECTION_ID";
    private String mObjectID = "YOUR_TEXT_OBJECT_ID";
    private String mPictureObjectID = "YOUR_IMAGE_OBJECT_ID";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_download);

//        SharedPreferences appPreferences = mContext.getSharedPreferences("Storage API",
//                                                                         Context.MODE_PRIVATE);
//        mCollectionID =  appPreferences.getString("CollectionID", "");
//
//
//        mPictureObjectID = appPreferences.getString("PictureObjectID","");
//        mObjectID = appPreferences.getString("TextObjectID", "");

        Button mdownloadText = (Button)findViewById(R.id.button_downloaddtext);
        Button mdownloadPicture = (Button)findViewById(R.id.download_picturebutton);

        mdownloadPicture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    //Initialize and obtain the storage client
                    mStorage = MobileBackendManager.getManager().getDefaultMobileBackend(mContext).getServiceProxy(Storage.class);
                    //Fetch the collection
                    StorageCollection collection = mStorage.getStorageCollection(mCollectionID);
                    //Fetch the object
                    StorageObject object = collection.get(mPictureObjectID);
                    //Get the payload
                    InputStream payload = object.getPayloadStream();
                    //Display the image
                    ImageView imageView = (ImageView) findViewById(R.id.imageView);
                    imageView.setImageBitmap(BitmapFactory.decodeStream(payload));

                } catch (ServiceProxyException e) {
                    e.printStackTrace();
                }
            }
        });

        mdownloadText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    launchDownloadTextActivity();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }
    private void launchDownloadTextActivity() throws IOException {
        try {
            //Initialize and obtain the storage client
            mStorage = MobileBackendManager.getManager().getDefaultMobileBackend(mContext).getServiceProxy(Storage.class);
            //Fetch the collection
            StorageCollection collection = mStorage.getStorageCollection(mCollectionID);
            //Fetch the object
            StorageObject object = collection.get(mObjectID);
            //Get the payload
            InputStream payload = object.getPayloadStream();
            //Display the object based off of Object ID. Text for now
            String text = getStringFromInputStream(payload);
            TextView textView = (TextView)findViewById(R.id.textView);
            textView.setText(text);
        } catch (ServiceProxyException e) {
            e.printStackTrace();
        }
    }

    private String getStringFromInputStream(InputStream payload) throws IOException {
        int n;
        char[] buffer = new char[1024 * 4];
        InputStreamReader reader = null;
        try {
            reader = new InputStreamReader(payload, "UTF8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        StringWriter writer = new StringWriter();
        assert reader != null;
        while (-1 != (n = reader.read(buffer))) writer.write(buffer, 0, n);
        return writer.toString();
    }
}






