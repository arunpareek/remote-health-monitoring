package oracle.cloud.mobile.gettingstarted;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import oracle.cloud.mobile.exception.ServiceProxyException;
import oracle.cloud.mobile.mobilebackend.MobileBackendManager;
import oracle.cloud.mobile.storage.Storage;
import oracle.cloud.mobile.storage.StorageCollection;
import oracle.cloud.mobile.storage.StorageObject;


public class UploadActivity extends Activity {

    /*************************************************************************************************************
     *                                                                                                           *
     *               Please explicitly specify the following parameters for Storage Client                       *
     *                                                                                                           *
     *               collectionID --- The id for the target collection                                           *                                                *
     *               payload -- The payload for the object to be uploaded                                        *
     *               contentType -- Content-Type of the payload                                                  *
     *                                                                                                           *
     *                                                                                                           *
     *************************************************************************************************************/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);
        Button muploadText = (Button)findViewById(R.id.button_uploadtext);
        Button mUploadPicture = (Button)findViewById(R.id.upload_picturebutton);
        muploadText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                launchUploadTextActivity();
            }
        });
        mUploadPicture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchUploadPictureActivity();
            }
        });
    }

    private void launchUploadTextActivity() {
        Intent intent = new Intent(this, UploadText_Activity.class);
        startActivity(intent);
    }
    private void launchUploadPictureActivity() {
        Intent intent = new Intent(this, UploadPictureActivity.class);
        startActivity(intent);
    }

}
