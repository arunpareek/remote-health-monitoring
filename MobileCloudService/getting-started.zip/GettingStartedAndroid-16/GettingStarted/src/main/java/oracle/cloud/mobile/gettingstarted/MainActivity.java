package oracle.cloud.mobile.gettingstarted;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import oracle.cloud.mobile.exception.ServiceProxyException;
import oracle.cloud.mobile.mobilebackend.MobileBackendManager;
import oracle.cloud.mobile.notifications.Notifications;


public class MainActivity extends Activity {

    private Notifications mNotification;

    /*************************************************************************
     *                                                                       *
     *       If Notification client is used in this app,                     *
     *              please also give the correct project ID                  *
     *                                                                       *
     *       The project ID could be copied from the Google API Console      *
     *                                                                       *
     *************************************************************************/

    private final String PROJECT_ID = "YOUR_PROJECT_ID";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.registerNotificationClient();

        Button button_uploadActivity = (Button) findViewById(R.id.button_uploadActivity);
        button_uploadActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getCurrentActivity(),UploadActivity.class);
                startActivity(intent);
            }
        });

        Button button_downloadActivity = (Button) findViewById(R.id.button_downloadActivity);
        button_downloadActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getCurrentActivity(), DownloadActivity.class);
                startActivity(intent);
            }
        });

    }


    /*************************************************************************************************************
     *                                                                                                           *
     *                      This method initializes and returns the Notifications Client                         *
     *                                                                                                           *
     *                                                                                                           *
     *************************************************************************************************************/

    private void registerNotificationClient(){
        try {
            mNotification = MobileBackendManager.getManager().getDefaultMobileBackend(this).getServiceProxy(Notifications.class);
            mNotification.initialize(this, PROJECT_ID);
        } catch (ServiceProxyException e) {
            e.printStackTrace();
        }
    }

    private Activity getCurrentActivity(){
        return this;
    }

}
