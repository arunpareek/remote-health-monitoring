package oracle.cloud.mobile.gettingstarted;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;

import oracle.cloud.mobile.exception.ServiceProxyException;
import oracle.cloud.mobile.logger.Logger;
import oracle.cloud.mobile.mobilebackend.MobileBackendManager;
import oracle.cloud.mobile.storage.Storage;
import oracle.cloud.mobile.storage.StorageCollection;
import oracle.cloud.mobile.storage.StorageObject;


public class UploadPictureActivity extends Activity {
    private static int RESULT_LOAD_IMG = 1;
    private Storage mStorage;
    private Context mContext = this;
    byte[] imageBytes;
    String objectID= "";
    private String collectionID = "YOUR_COLLECTION_NAME";
    private String mContentType = "image/jpeg"; //can be other MIME types;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_picture);
    }

    public void loadImagefromGallery(View view) {
        Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(cameraIntent, RESULT_LOAD_IMG);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            // When an Image is picked
            if (requestCode == RESULT_LOAD_IMG && resultCode == RESULT_OK
                    && null != data) {
                Bitmap imageReturned = (Bitmap) data.getExtras().get("data");
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                imageReturned.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                imageBytes = baos.toByteArray();
                ImageView imgView = (ImageView) findViewById(R.id.imgView);
                // Set the Image in ImageView after decoding the String
                imgView.setImageBitmap(imageReturned);

            } else {
                Toast.makeText(this, "You haven't picked Image",
                        Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Something went wrong", Toast.LENGTH_LONG)
                    .show();
        }
    }

    public void uploadImage(View view){
        new UploadImageTask().execute();

    }

    private void launchMainActivity() {
        Toast.makeText(getApplicationContext(), "Upload successful",
                Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(getCurrentActivity(), MainActivity.class);
        startActivity(intent);
    }

    private Activity getCurrentActivity() {
        return this;
    }

//    private void SavePreferences(String collection, String objectID) {
//        SharedPreferences appPreferences = this.getSharedPreferences("Storage API",
//                Context.MODE_PRIVATE);
//        SharedPreferences.Editor prefEditor = appPreferences.edit();
//        prefEditor.putString("CollectionID", collection);
//        prefEditor.putString("PictureObjectID", objectID);
//        prefEditor.apply();
//    }

    class UploadImageTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... args) {
            String canonicalLink = null;

            if (imageBytes.length > 0) {
                try {

                    mStorage = MobileBackendManager.getManager().getDefaultMobileBackend(mContext).getServiceProxy(Storage.class);
                    StorageCollection imagesCollection = mStorage.getStorageCollection(collectionID);
                    StorageObject imageToUpload = new StorageObject(null, imageBytes, mContentType);
                    StorageObject uploadedImage = imagesCollection.post(imageToUpload);
                    canonicalLink = uploadedImage.getCanonicalLink();
                    // Upload succeeded
//                    SavePreferences(collectionID,objectID);
                    launchMainActivity();
                } catch (ServiceProxyException e) {
                    // Upload failed
                }
            }

            return canonicalLink;
        }

        @Override
        protected void onPostExecute(String canonicalLink) {
            super.onPostExecute(canonicalLink);
            if (canonicalLink == null) {
                Toast.makeText(getApplicationContext(), "Something with wrong , Try again",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

}
